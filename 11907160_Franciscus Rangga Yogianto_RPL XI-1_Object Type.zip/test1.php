<?php
class produk{
  public $namaLaptop, 
          $merk, 
            $harga;
            public function cetakProduk(){
                return "$this->merk, (Rp $this->harga)";
            }
            public function __construct($namaLaptop="Nama Laptop : ", $merk="Merk : ", $harga = 0)
            {
                $this->namaLaptop = $namaLaptop;
                $this->merk = $merk;
                $this->harga = $harga;
            }    
}

Class cetakInfoproduk{
    public function cetakInfo(produk $produk){
        $str="{$produk->namaLaptop}, {$produk->cetakProduk()}";
        return $str;
    }
}
$produk1 = new produk("Predator","Acer",23000000);
$produk2 = new produk("ROG Strix","Asus",64000000);
$produk3 = new produk("Pavillion","HP",47000000);
$infoProduk = new cetakInfoproduk();

echo "Nama Barang Laptop : " . $produk1->cetakProduk();
echo "<br>";
echo "Nama Barang Laptop : " . $produk2->cetakProduk();
echo "<br>";
echo "Nama Barang Laptop : " . $produk3->cetakProduk();
echo "<br>";
echo $infoProduk->cetakInfo($produk3);

?>